(function(){function r(e,n,t){function o(i,f){if(!n[i]){if(!e[i]){var c="function"==typeof require&&require;if(!f&&c)return c(i,!0);if(u)return u(i,!0);var a=new Error("Cannot find module '"+i+"'");throw a.code="MODULE_NOT_FOUND",a}var p=n[i]={exports:{}};e[i][0].call(p.exports,function(r){var n=e[i][1][r];return o(n||r)},p,p.exports,r,e,n,t)}return n[i].exports}for(var u="function"==typeof require&&require,i=0;i<t.length;i++)o(t[i]);return o}return r})()({1:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = void 0;

var _miniapp = require("./miniapp");

var miniAppInstance = new _miniapp.MiniApp(); // tslint:disable-next-line:no-default-export

var _default = miniAppInstance;
exports.default = _default;

},{"./miniapp":2}],2:[function(require,module,exports){
"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.default = exports.MiniApp = void 0;

/* tslint:disable:no-any */
var MiniApp =
/** @class */
function () {
  function MiniApp() {}

  MiniApp.prototype.getUniqueId = function () {
    return window.MiniAppBridge.getUniqueId();
  };

  return MiniApp;
}();

exports.MiniApp = MiniApp;
// tslint:disable-next-line:no-default-export
var _default = MiniApp;
exports.default = _default;

},{}],3:[function(require,module,exports){
"use strict";

var _index = _interopRequireDefault(require("./index"));

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { default: obj }; }

function printUniqueId() {
  _index.default.getUniqueId().then(function (value) {
    document.getElementById('uniqueId').textContent = 'Unique ID: ' + value;
  }).catch(function (error) {
    console.log('ERROR:', error.message);
  });
}

var btnPrintUniqueId = document.getElementById('btnPrintUniqueId');
btnPrintUniqueId.addEventListener('click', function (e) {
  return printUniqueId();
});

},{"./index":1}]},{},[3]);
